package ca.uqam.info.mgl7460.domain;

public enum Session { Automne, Hiver, Printemps, Ete
    
}
